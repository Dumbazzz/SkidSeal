# TrinitySeal-End-To-End
Trinity Seals End To End Encryption

- Trinity Seal Is Using My End to end encryption Where He Claims It As His Own
Just Wanted Simple Credits For The Features He Claims as His Own that are Mine. Now His Users Will See His Lies Exposed With There Programs Being Affected/Possible Cracked , If Your A Trinity Seal User i Appologise If This Affects You This Is Why You Dont Help Children Who Dont Understand The Conecept Of Respect
 
- A Auto Crack File Will Be Released Here To Prove Point Of Concept That If You Write/Design The Key Parts Of The Auth You Can Crack it 


Yours Truely 

Epsilon Solutions 
