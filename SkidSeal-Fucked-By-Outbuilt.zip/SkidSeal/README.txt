TrinitySeal is skidded, here is the source of it, It only allows one program though. Enjoy :)

OUTBUILT.OOO

discord.gg/DhFatue